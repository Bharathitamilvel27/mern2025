import React from 'react'

const Child = (props) => {
  return (
  
    <div>Child name,phoneno, dept :{props.name} {props.phonenum} {props.dept}</div>
 

  )
}

export default Child