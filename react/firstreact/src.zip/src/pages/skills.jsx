import React from 'react'

const skills = () => {
  return (
    <div>skills</div>
  )
}

export default skills